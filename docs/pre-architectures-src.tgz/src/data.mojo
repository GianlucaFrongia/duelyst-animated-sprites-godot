# Loads the frame-pair dataset written by tools/prepare_animations.py, plus a tiny CLI arg helper.

from std.math import cos
from std.random import random_float64, random_ui64
from src.model import T, PP, NPIX, IMG, FRAME_PIX, tgt_pix


struct Dataset(Movable):
    var pixels: List[UInt8]  # N * NPIX (context frame on top, target frame below)
    var labels: List[UInt8]  # N
    var classes: List[String]
    var N: Int
    var V: Int
    var C: Int

    def __init__(out self, dir: String) raises:
        self.N = 0
        self.V = 0
        self.C = 0
        var size = 0
        var f = open(dir + "/meta.txt", "r")
        var txt = f.read()
        f.close()
        for line in txt.splitlines():
            var kv = line.split(" ")
            if len(kv) < 2:
                continue
            if kv[0] == "N":
                self.N = Int(kv[1])
            elif kv[0] == "V":
                self.V = Int(kv[1])
            elif kv[0] == "C":
                self.C = Int(kv[1])
            elif kv[0] == "S":
                size = Int(kv[1])
        if size != IMG:
            raise Error("dataset frames are " + String(size) + "px, the model expects " + String(IMG)
                        + "px: re-run tools/prepare_animations.py")
        var pf = open(dir + "/pixels.bin", "r")
        self.pixels = pf.read_bytes()
        pf.close()
        var lf = open(dir + "/labels.bin", "r")
        self.labels = lf.read_bytes()
        lf.close()
        if len(self.pixels) != self.N * NPIX or len(self.labels) != self.N:
            raise Error("dataset files do not match meta.txt")
        self.classes = List[String]()
        var cf = open(dir + "/classes.txt", "r")
        var ctxt = cf.read()
        cf.close()
        for line in ctxt.splitlines():
            if line.byte_length() > 0:
                self.classes.append(String(line))

    def pair(self, i: Int, flip: Bool, mut out: List[Int]):
        """Copies frame pair i into out (NPIX palette indices), optionally mirrored horizontally."""
        var base = i * NPIX
        for y in range(2 * IMG):
            for x in range(IMG):
                var sx = IMG - 1 - x if flip else x
                out[y * IMG + x] = Int(self.pixels[base + y * IMG + sx])


def read_frame(dir: String, i: Int) raises -> List[Int]:
    """The context (top) frame of pair i, read without loading the whole dataset."""
    if i < 0:
        raise Error("pair index must be >= 0, got " + String(i))
    var f = open(dir + "/pixels.bin", "r")
    _ = f.seek(i * NPIX)
    var b = f.read_bytes(FRAME_PIX)
    f.close()
    if len(b) != FRAME_PIX:
        raise Error("pair " + String(i) + " is past the end of " + dir + "/pixels.bin")
    var out = List[Int](length=FRAME_PIX, fill=0)
    for p in range(FRAME_PIX):
        out[p] = Int(b[p])
    return out^


def random_mask(mut mask: List[Bool], mut order: List[Int]) -> Int:
    """MaskGIT cosine schedule: mask a random fraction cos(pi/2 * u) of the tokens (all of
    them are target-frame tokens). Returns count."""
    var u = random_float64()
    var ratio = cos(1.5707963267948966 * u)
    var n = Int(ratio * Float64(T) + 0.999)
    n = max(1, min(T, n))
    for t in range(T):
        mask[t] = False
        order[t] = t
    for i in range(n):  # partial Fisher-Yates shuffle
        var j = i + Int(random_ui64(0, UInt64(T - 1 - i)))
        var tmp = order[i]
        order[i] = order[j]
        order[j] = tmp
        mask[order[i]] = True
    return n


def apply_mask(mut ids: List[Int], target: List[Int], mask: List[Bool], mask_id: Int, blank_context: Bool):
    """Masks the selected tokens. blank_context also hides the whole context frame, which
    teaches the model to draw a first frame from nothing."""
    for i in range(NPIX):
        ids[i] = target[i]
    if blank_context:
        for i in range(FRAME_PIX):
            ids[i] = mask_id
    for t in range(T):
        if mask[t]:
            for k in range(PP):
                ids[tgt_pix(t, k)] = mask_id


# ------------------------------------------------------------------ CLI args


def arg_str(args: List[String], name: String, default: String) -> String:
    for i in range(len(args) - 1):
        if args[i] == name:
            return args[i + 1]
    return default


def arg_int(args: List[String], name: String, default: Int) raises -> Int:
    var s = arg_str(args, name, "")
    return Int(s) if s.byte_length() > 0 else default


def arg_float(args: List[String], name: String, default: Float64) raises -> Float64:
    var s = arg_str(args, name, "")
    return Float64(s) if s.byte_length() > 0 else default
