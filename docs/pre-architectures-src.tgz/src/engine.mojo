# Batched training engine that runs every forward/backward op as a GPU kernel.
#
# Each op is written once as a per-thread "body" function b_*(..., i). On a GPU build
# the body is launched as a kernel k_* (one thread per output element); otherwise the
# same body runs in a plain CPU loop. That CPU path is slow, but it lets us test the
# exact kernel logic against the gradient-checked reference model (gpu_check.mojo).
#
# All activations for the whole batch stay in device memory. Rows are batch-major:
# row r = b * T + t. Only the batch inputs go up and a few scalars come back per step.

from std.math import sqrt, exp, tanh, log
from std.sys import has_accelerator
from std.memory import stack_allocation
from max.gpu import global_idx, thread_idx, block_idx, barrier
from max.gpu.memory import AddressSpace
from max.gpu.host import DeviceContext, DeviceBuffer
from src.model import Config, Model, T, PP, SLOTS, NPIX, tgt_pix, slot_pix

comptime FP = Pointer[Float32, MutAnyOrigin]
comptime IP = Pointer[Int32, MutAnyOrigin]
comptime BLOCK = 256
comptime NCHUNK = 1024  # partial sums for gradient norm and loss
comptime TK = 16  # K-slice held in shared memory by the tiled matmul
comptime SPLITK = 32  # max K-splits for weight-gradient matmuls (K = B*T rows, few output tiles)
comptime GELU_C: Float32 = 0.7978845608


def blocks(n: Int) -> Int:
    return (n + BLOCK - 1) // BLOCK


# ============================================================================ op bodies
# Each body computes one output element (or one row / column) for thread index i.


def b_fill(p: FP, v: Float32, i: Int):
    p[unsafe_offset=i] = v


def b_axpy(y: FP, x: FP, a: Float32, i: Int):
    y[unsafe_offset=i] += a * x[unsafe_offset=i]


def b_gemm(c: FP, a: FP, b: FP, M: Int, N: Int, K: Int, H: Int,
           sAi: Int, sAk: Int, sBk: Int, sBj: Int, sCi: Int, sCj: Int,
           zbA: Int, zhA: Int, zbB: Int, zhB: Int, zbC: Int, zhC: Int,
           alpha: Float32, acc: Int, i: Int):
    """Strided, batched C = alpha * A @ B. Batch index z splits into (z // H, z % H)
    so one launch covers every (sprite, head) pair in attention."""
    var mn = M * N
    var z = i // mn
    var rem = i - z * mn
    var row = rem // N
    var col = rem - row * N
    var zb = z // H
    var zh = z - zb * H
    var pa = a.unsafe_offset(zb * zbA + zh * zhA + row * sAi)
    var pb = b.unsafe_offset(zb * zbB + zh * zhB + col * sBj)
    var s: Float32 = 0.0
    for k in range(K):
        s += pa[unsafe_offset=k * sAk] * pb[unsafe_offset=k * sBk]
    var o = zb * zbC + zh * zhC + row * sCi + col * sCj
    if acc != 0:
        c[unsafe_offset=o] += alpha * s
    else:
        c[unsafe_offset=o] = alpha * s


def b_add_bias(y: FP, bias: FP, O: Int, i: Int):
    y[unsafe_offset=i] += bias[unsafe_offset=i % O]


def b_bias_grad(db: FP, dy: FP, R: Int, O: Int, i: Int):
    var s: Float32 = 0.0
    for r in range(R):
        s += dy[unsafe_offset=r * O + i]
    db[unsafe_offset=i] += s


def b_ln_fwd(y: FP, xhat: FP, rstd: FP, x: FP, g: FP, b: FP, D: Int, i: Int):
    var xr = x.unsafe_offset(i * D)
    var mean: Float32 = 0.0
    for d in range(D):
        mean += xr[unsafe_offset=d]
    mean /= Float32(D)
    var v: Float32 = 0.0
    for d in range(D):
        var e = xr[unsafe_offset=d] - mean
        v += e * e
    v /= Float32(D)
    var r = 1.0 / sqrt(v + 1e-5)
    rstd[unsafe_offset=i] = r
    for d in range(D):
        var xh = (xr[unsafe_offset=d] - mean) * r
        xhat[unsafe_offset=i * D + d] = xh
        y[unsafe_offset=i * D + d] = xh * g[unsafe_offset=d] + b[unsafe_offset=d]


def b_ln_bwd_dx(dx: FP, dy: FP, xhat: FP, rstd: FP, g: FP, D: Int, i: Int):
    var m1: Float32 = 0.0
    var m2: Float32 = 0.0
    for d in range(D):
        var dxh = dy[unsafe_offset=i * D + d] * g[unsafe_offset=d]
        m1 += dxh
        m2 += dxh * xhat[unsafe_offset=i * D + d]
    m1 /= Float32(D)
    m2 /= Float32(D)
    var r = rstd[unsafe_offset=i]
    for d in range(D):
        var o = i * D + d
        dx[unsafe_offset=o] += r * (dy[unsafe_offset=o] * g[unsafe_offset=d] - m1 - xhat[unsafe_offset=o] * m2)


def b_ln_bwd_dgb(dg: FP, db: FP, dy: FP, xhat: FP, R: Int, D: Int, i: Int):
    var sg: Float32 = 0.0
    var sb: Float32 = 0.0
    for r in range(R):
        var d = dy[unsafe_offset=r * D + i]
        sg += d * xhat[unsafe_offset=r * D + i]
        sb += d
    dg[unsafe_offset=i] += sg
    db[unsafe_offset=i] += sb


def b_gelu_fwd(y: FP, x: FP, i: Int):
    var v = x[unsafe_offset=i]
    y[unsafe_offset=i] = 0.5 * v * (1.0 + tanh(GELU_C * (v + 0.044715 * v * v * v)))


def b_gelu_bwd(dx: FP, dy: FP, x: FP, i: Int):
    var v = x[unsafe_offset=i]
    var th = tanh(GELU_C * (v + 0.044715 * v * v * v))
    var d = 0.5 * (1.0 + th) + 0.5 * v * (1.0 - th * th) * GELU_C * (1.0 + 3.0 * 0.044715 * v * v)
    dx[unsafe_offset=i] = dy[unsafe_offset=i] * d


def b_softmax(p: FP, n: Int, i: Int):
    var row = p.unsafe_offset(i * n)
    var mx = row[unsafe_offset=0]
    for j in range(1, n):
        mx = max(mx, row[unsafe_offset=j])
    var s: Float32 = 0.0
    for j in range(n):
        var e = exp(row[unsafe_offset=j] - mx)
        row[unsafe_offset=j] = e
        s += e
    var inv = 1.0 / s
    for j in range(n):
        row[unsafe_offset=j] *= inv


def b_softmax_bwd(dp: FP, p: FP, n: Int, scale: Float32, i: Int):
    """dp <- P * (dP - sum(P * dP)) * scale, row i."""
    var s: Float32 = 0.0
    for j in range(n):
        s += p[unsafe_offset=i * n + j] * dp[unsafe_offset=i * n + j]
    for j in range(n):
        var o = i * n + j
        dp[unsafe_offset=o] = p[unsafe_offset=o] * (dp[unsafe_offset=o] - s) * scale


def b_embed(x: FP, w: FP, ids: IP, cls: IP, o_tok: Int, o_pos: Int, o_cls: Int,
            D: Int, V: Int, i: Int):
    var r = i // D
    var d = i - r * D
    var b = r // T
    var t = r - b * T
    var v = w[unsafe_offset=o_pos + t * D + d] + w[unsafe_offset=o_cls + Int(cls[unsafe_offset=b]) * D + d]
    for s in range(SLOTS):
        var id = Int(ids[unsafe_offset=b * NPIX + slot_pix(t, s)])
        v += w[unsafe_offset=o_tok + (s * (V + 1) + id) * D + d]
    x[unsafe_offset=i] = v


def b_embed_bwd_pos(g: FP, dx: FP, o_pos: Int, B: Int, D: Int, i: Int):
    var s: Float32 = 0.0
    for b in range(B):
        s += dx[unsafe_offset=b * T * D + i]
    g[unsafe_offset=o_pos + i] += s


def b_embed_bwd_cls(g: FP, dx: FP, cls: IP, o_cls: Int, B: Int, D: Int, i: Int):
    var c = i // D
    var d = i - c * D
    var s: Float32 = 0.0
    for b in range(B):
        if Int(cls[unsafe_offset=b]) == c:
            for t in range(T):
                s += dx[unsafe_offset=(b * T + t) * D + d]
    g[unsafe_offset=o_cls + i] += s


def b_embed_bwd_tok(g: FP, dx: FP, ids: IP, o_tok: Int, B: Int, D: Int, V: Int, i: Int):
    var d = i % D
    var sv = i // D
    var slot = sv // (V + 1)
    var v = sv - slot * (V + 1)
    var s: Float32 = 0.0
    for b in range(B):
        for t in range(T):
            if Int(ids[unsafe_offset=b * NPIX + slot_pix(t, slot)]) == v:
                s += dx[unsafe_offset=(b * T + t) * D + d]
    g[unsafe_offset=o_tok + i] += s


def b_loss(dl: FP, lossbuf: FP, logits: FP, tgt: IP, mask: IP, gscale: FP, V: Int, i: Int):
    """One (token, sub-pixel) per thread. lossbuf sums to the batch-mean loss."""
    var r = i // PP
    var k = i - r * PP
    var b = r // T
    var t = r - b * T
    var row = logits.unsafe_offset(i * V)
    var drow = dl.unsafe_offset(i * V)
    if mask[unsafe_offset=r] == 0:
        for j in range(V):
            drow[unsafe_offset=j] = 0.0
        lossbuf[unsafe_offset=i] = 0.0
        return
    var mx = row[unsafe_offset=0]
    for j in range(1, V):
        mx = max(mx, row[unsafe_offset=j])
    var s: Float32 = 0.0
    for j in range(V):
        var e = exp(row[unsafe_offset=j] - mx)
        drow[unsafe_offset=j] = e
        s += e
    var tg = Int(tgt[unsafe_offset=b * NPIX + tgt_pix(t, k)])
    var gs = gscale[unsafe_offset=b]
    lossbuf[unsafe_offset=i] = -(row[unsafe_offset=tg] - mx - log(s)) * gs
    for j in range(V):
        var p = drow[unsafe_offset=j] / s
        drow[unsafe_offset=j] = gs * (p - (Float32(1.0) if j == tg else Float32(0.0)))


def b_chunk_sum(dst: FP, x: FP, n: Int, square: Int, i: Int):
    var per = (n + NCHUNK - 1) // NCHUNK
    var s: Float32 = 0.0
    for j in range(i * per, min(n, (i + 1) * per)):
        var v = x[unsafe_offset=j]
        s += v * v if square != 0 else v
    dst[unsafe_offset=i] = s


def b_adamw(w: FP, g: FP, m: FP, v: FP, dec: FP, gmul: Float32, lr: Float32,
            c1: Float32, c2: Float32, wd: Float32, i: Int):
    var b1: Float32 = 0.9
    var b2: Float32 = 0.95
    var gi = g[unsafe_offset=i] * gmul
    var mi = b1 * m[unsafe_offset=i] + (1.0 - b1) * gi
    var vi = b2 * v[unsafe_offset=i] + (1.0 - b2) * gi * gi
    m[unsafe_offset=i] = mi
    v[unsafe_offset=i] = vi
    var upd = (mi / c1) / (sqrt(vi / c2) + 1e-8) + wd * dec[unsafe_offset=i] * w[unsafe_offset=i]
    w[unsafe_offset=i] -= lr * upd


# ============================================================================ GPU kernels
# Thin wrappers: thread index -> body. Scalars are Int32 because Int is not device-passable.


def k_fill(p: FP, v: Float32, n: Int32):
    var i = Int(global_idx.x)
    if i < Int(n):
        b_fill(p, v, i)


def k_axpy(y: FP, x: FP, a: Float32, n: Int32):
    var i = Int(global_idx.x)
    if i < Int(n):
        b_axpy(y, x, a, i)


def k_gemm(c: FP, a: FP, b: FP, M: Int32, N: Int32, K: Int32, H: Int32,
           sAi: Int32, sAk: Int32, sBk: Int32, sBj: Int32, sCi: Int32, sCj: Int32,
           zbA: Int32, zhA: Int32, zbB: Int32, zhB: Int32, zbC: Int32, zhC: Int32,
           alpha: Float32, acc: Int32, n: Int32):
    var i = Int(global_idx.x)
    if i < Int(n):
        b_gemm(c, a, b, Int(M), Int(N), Int(K), Int(H), Int(sAi), Int(sAk), Int(sBk), Int(sBj),
               Int(sCi), Int(sCj), Int(zbA), Int(zhA), Int(zbB), Int(zhB), Int(zbC), Int(zhC),
               alpha, Int(acc), i)


def k_gemm_tiled[TM: Int, TN: Int, RM: Int, RN: Int](
        c: FP, a: FP, b: FP, M: Int32, N: Int32, K: Int32, H: Int32,
        sAi: Int32, sAk: Int32, sBk: Int32, sBj: Int32, sCi: Int32, sCj: Int32,
        zbA: Int32, zhA: Int32, zbB: Int32, zhB: Int32, zbC: Int32, zhC: Int32,
        alpha: Float32, acc: Int32, tiles_m: Int32, tiles_n: Int32):
    """Same contract as b_gemm, but one 256-thread block computes a TM x TN tile of C.
    A and B are staged through shared memory TK columns at a time, and each thread keeps
    an RM x RN block of outputs in registers. Rows/columns of a thread's block are strided
    by the thread-grid size, so shared-memory reads and global writes stay contiguous."""
    comptime TX = TN // RN
    comptime TY = TM // RM
    comptime LDA = TM + 1  # +1 padding avoids bank conflicts on transposed stores
    comptime LDB = TN + 1
    var As = stack_allocation[TK * LDA, Float32, address_space=AddressSpace.SHARED]()
    var Bs = stack_allocation[TK * LDB, Float32, address_space=AddressSpace.SHARED]()
    var tid = Int(thread_idx.x)
    var blk = Int(block_idx.x)
    var nm = Int(M)
    var nn = Int(N)
    var nk = Int(K)
    var per_z = Int(tiles_m) * Int(tiles_n)
    var z = blk // per_z
    var rem = blk - z * per_z
    var tm = rem // Int(tiles_n)
    var tn = rem - tm * Int(tiles_n)
    var zb = z // Int(H)
    var zh = z - zb * Int(H)
    var pa = a.unsafe_offset(zb * Int(zbA) + zh * Int(zhA))
    var pb = b.unsafe_offset(zb * Int(zbB) + zh * Int(zhB))
    var ai = Int(sAi)
    var ak = Int(sAk)
    var bk = Int(sBk)
    var bj = Int(sBj)
    var row0 = tm * TM
    var col0 = tn * TN
    var ty = tid // TX
    var tx = tid - ty * TX
    var accv = SIMD[DType.float32, RM * RN](0.0)

    for k0 in range(0, nk, TK):
        # Stage A[row0:row0+TM, k0:k0+TK]; neighbouring threads follow A's unit stride.
        comptime for e in range((TK * TM) // 256):
            var idx = tid + e * 256
            var r: Int
            var kk: Int
            if ak == 1:
                r = idx // TK
                kk = idx - r * TK
            else:
                kk = idx // TM
                r = idx - kk * TM
            var v: Float32 = 0.0
            if row0 + r < nm and k0 + kk < nk:
                v = pa[unsafe_offset=(row0 + r) * ai + (k0 + kk) * ak]
            As[unsafe_offset=kk * LDA + r] = v
        # Stage B[k0:k0+TK, col0:col0+TN].
        comptime for e in range((TK * TN) // 256):
            var idx = tid + e * 256
            var cc: Int
            var kk: Int
            if bj == 1:
                kk = idx // TN
                cc = idx - kk * TN
            else:
                cc = idx // TK
                kk = idx - cc * TK
            var v: Float32 = 0.0
            if col0 + cc < nn and k0 + kk < nk:
                v = pb[unsafe_offset=(k0 + kk) * bk + (col0 + cc) * bj]
            Bs[unsafe_offset=kk * LDB + cc] = v
        barrier()
        for kk in range(TK):
            var av = SIMD[DType.float32, RM](0.0)
            comptime for i in range(RM):
                av[i] = As[unsafe_offset=kk * LDA + ty + i * TY]
            comptime for j in range(RN):
                var bv = Bs[unsafe_offset=kk * LDB + tx + j * TX]
                comptime for i in range(RM):
                    accv[i * RN + j] += av[i] * bv
        barrier()

    var cb = zb * Int(zbC) + zh * Int(zhC)
    comptime for i in range(RM):
        var r = row0 + ty + i * TY
        if r < nm:
            comptime for j in range(RN):
                var cc = col0 + tx + j * TX
                if cc < nn:
                    var o = cb + r * Int(sCi) + cc * Int(sCj)
                    var v = alpha * accv[i * RN + j]
                    if acc != 0:
                        c[unsafe_offset=o] += v
                    else:
                        c[unsafe_offset=o] = v


def k_splitk_reduce(c: FP, part: FP, S: Int32, M: Int32, N: Int32, sCi: Int32, sCj: Int32,
                    alpha: Float32, acc: Int32):
    """C (+)= alpha * sum over the S partial products written by a split-K gemm."""
    var i = Int(global_idx.x)
    var mn = Int(M) * Int(N)
    if i >= mn:
        return
    var s: Float32 = 0.0
    for k in range(Int(S)):
        s += part[unsafe_offset=k * mn + i]
    var row = i // Int(N)
    var col = i - row * Int(N)
    var o = row * Int(sCi) + col * Int(sCj)
    if acc != 0:
        c[unsafe_offset=o] += alpha * s
    else:
        c[unsafe_offset=o] = alpha * s


def k_add_bias(y: FP, bias: FP, O: Int32, n: Int32):
    var i = Int(global_idx.x)
    if i < Int(n):
        b_add_bias(y, bias, Int(O), i)


def k_colsum_partial(part: FP, dy: FP, xhat: FP, R: Int32, O: Int32, S: Int32, with_xhat: Int32):
    """Column sums of dy over one of S row-chunks; thread i = (chunk, column). With xhat it
    also sums dy * xhat (the layer-norm gain gradient) into the second half of the chunk."""
    var i = Int(global_idx.x)
    var o = Int(O)
    if i >= Int(S) * o:
        return
    var s = i // o
    var col = i - s * o
    var per = (Int(R) + Int(S) - 1) // Int(S)
    var sb: Float32 = 0.0
    var sg: Float32 = 0.0
    for r in range(s * per, min(Int(R), (s + 1) * per)):
        var d = dy[unsafe_offset=r * o + col]
        sb += d
        if with_xhat != 0:
            sg += d * xhat[unsafe_offset=r * o + col]
    part[unsafe_offset=s * 2 * o + col] = sb
    part[unsafe_offset=s * 2 * o + o + col] = sg


def k_colsum_reduce(db: FP, dg: FP, part: FP, O: Int32, S: Int32, with_xhat: Int32):
    var i = Int(global_idx.x)
    var o = Int(O)
    if i >= o:
        return
    var sb: Float32 = 0.0
    var sg: Float32 = 0.0
    for s in range(Int(S)):
        sb += part[unsafe_offset=s * 2 * o + i]
        sg += part[unsafe_offset=s * 2 * o + o + i]
    db[unsafe_offset=i] += sb
    if with_xhat != 0:
        dg[unsafe_offset=i] += sg


def k_bias_grad(db: FP, dy: FP, R: Int32, O: Int32):
    var i = Int(global_idx.x)
    if i < Int(O):
        b_bias_grad(db, dy, Int(R), Int(O), i)


def k_ln_fwd(y: FP, xhat: FP, rstd: FP, x: FP, g: FP, b: FP, D: Int32, n: Int32):
    var i = Int(global_idx.x)
    if i < Int(n):
        b_ln_fwd(y, xhat, rstd, x, g, b, Int(D), i)


def k_ln_bwd_dx(dx: FP, dy: FP, xhat: FP, rstd: FP, g: FP, D: Int32, n: Int32):
    var i = Int(global_idx.x)
    if i < Int(n):
        b_ln_bwd_dx(dx, dy, xhat, rstd, g, Int(D), i)


def k_ln_bwd_dgb(dg: FP, db: FP, dy: FP, xhat: FP, R: Int32, D: Int32):
    var i = Int(global_idx.x)
    if i < Int(D):
        b_ln_bwd_dgb(dg, db, dy, xhat, Int(R), Int(D), i)


def k_gelu_fwd(y: FP, x: FP, n: Int32):
    var i = Int(global_idx.x)
    if i < Int(n):
        b_gelu_fwd(y, x, i)


def k_gelu_bwd(dx: FP, dy: FP, x: FP, n: Int32):
    var i = Int(global_idx.x)
    if i < Int(n):
        b_gelu_bwd(dx, dy, x, i)


def k_softmax(p: FP, cols: Int32, rows: Int32):
    var i = Int(global_idx.x)
    if i < Int(rows):
        b_softmax(p, Int(cols), i)


def block_reduce(red: Pointer[Float32, MutUntrackedOrigin, address_space=AddressSpace.SHARED],
                 v: Float32, tid: Int, is_max: Bool) -> Float32:
    """Max or sum of v over the 256 threads of a block (every thread must call it)."""
    red[unsafe_offset=tid] = v
    barrier()
    var step = 128
    while step > 0:
        if tid < step:
            var o = red[unsafe_offset=tid + step]
            var mine = red[unsafe_offset=tid]
            red[unsafe_offset=tid] = max(mine, o) if is_max else mine + o
        barrier()
        step //= 2
    var r = red[unsafe_offset=0]
    barrier()
    return r


def k_softmax_rows(p: FP, cols: Int32):
    """Row softmax with one 256-thread block per row, so neighbouring threads read
    neighbouring columns (b_softmax's one-thread-per-row reads are scattered)."""
    var red = stack_allocation[256, Float32, address_space=AddressSpace.SHARED]()
    var tid = Int(thread_idx.x)
    var n = Int(cols)
    var row = p.unsafe_offset(Int(block_idx.x) * n)
    var mx: Float32 = -3.0e38
    for j in range(tid, n, 256):
        mx = max(mx, row[unsafe_offset=j])
    mx = block_reduce(red, mx, tid, True)
    var s: Float32 = 0.0
    for j in range(tid, n, 256):
        var e = exp(row[unsafe_offset=j] - mx)
        row[unsafe_offset=j] = e
        s += e
    var inv = 1.0 / block_reduce(red, s, tid, False)
    for j in range(tid, n, 256):
        row[unsafe_offset=j] *= inv


def k_softmax_bwd_rows(dp: FP, p: FP, cols: Int32, scale: Float32):
    var red = stack_allocation[256, Float32, address_space=AddressSpace.SHARED]()
    var tid = Int(thread_idx.x)
    var n = Int(cols)
    var base = Int(block_idx.x) * n
    var s: Float32 = 0.0
    for j in range(tid, n, 256):
        s += p[unsafe_offset=base + j] * dp[unsafe_offset=base + j]
    s = block_reduce(red, s, tid, False)
    for j in range(tid, n, 256):
        var o = base + j
        dp[unsafe_offset=o] = p[unsafe_offset=o] * (dp[unsafe_offset=o] - s) * scale


def k_softmax_bwd(dp: FP, p: FP, cols: Int32, scale: Float32, rows: Int32):
    var i = Int(global_idx.x)
    if i < Int(rows):
        b_softmax_bwd(dp, p, Int(cols), scale, i)


def k_embed(x: FP, w: FP, ids: IP, cls: IP, o_tok: Int32, o_pos: Int32, o_cls: Int32,
            D: Int32, V: Int32, n: Int32):
    var i = Int(global_idx.x)
    if i < Int(n):
        b_embed(x, w, ids, cls, Int(o_tok), Int(o_pos), Int(o_cls), Int(D), Int(V), i)


def k_embed_bwd_pos(g: FP, dx: FP, o_pos: Int32, B: Int32, D: Int32, n: Int32):
    var i = Int(global_idx.x)
    if i < Int(n):
        b_embed_bwd_pos(g, dx, Int(o_pos), Int(B), Int(D), i)


def k_embed_bwd_cls(g: FP, dx: FP, cls: IP, o_cls: Int32, B: Int32, D: Int32, n: Int32):
    var i = Int(global_idx.x)
    if i < Int(n):
        b_embed_bwd_cls(g, dx, cls, Int(o_cls), Int(B), Int(D), i)


def k_embed_bwd_tok(g: FP, dx: FP, ids: IP, o_tok: Int32, B: Int32, D: Int32, V: Int32, n: Int32):
    var i = Int(global_idx.x)
    if i < Int(n):
        b_embed_bwd_tok(g, dx, ids, Int(o_tok), Int(B), Int(D), Int(V), i)


def k_loss(dl: FP, lossbuf: FP, logits: FP, tgt: IP, mask: IP, gscale: FP, V: Int32, n: Int32):
    var i = Int(global_idx.x)
    if i < Int(n):
        b_loss(dl, lossbuf, logits, tgt, mask, gscale, Int(V), i)


def k_chunk_sum(dst: FP, x: FP, n: Int32, square: Int32):
    var i = Int(global_idx.x)
    if i < NCHUNK:
        b_chunk_sum(dst, x, Int(n), Int(square), i)


def k_adamw(w: FP, g: FP, m: FP, v: FP, dec: FP, gmul: Float32, lr: Float32,
            c1: Float32, c2: Float32, wd: Float32, n: Int32):
    var i = Int(global_idx.x)
    if i < Int(n):
        b_adamw(w, g, m, v, dec, gmul, lr, c1, c2, wd, i)


# ============================================================================ engine


def _fp(l: List[Float32]) -> FP:
    return l.unsafe_ptr().unsafe_mut_cast[True]().unsafe_origin_cast[MutAnyOrigin]()


def _ip(l: List[Int32]) -> IP:
    return l.unsafe_ptr().unsafe_mut_cast[True]().unsafe_origin_cast[MutAnyOrigin]()


struct Engine(Movable):
    var cfg: Config
    var B: Int
    var R: Int  # B * T rows
    var gpu: Bool
    var ctx: Optional[DeviceContext]
    var fdev: Optional[DeviceBuffer[DType.float32]]
    var idev: Optional[DeviceBuffer[DType.int32]]
    var fhost: List[Float32]  # CPU-emulation storage
    var ihost: List[Int32]
    var nparam: Int
    # offsets into the float arena
    var o_w: Int
    var o_g: Int
    var o_m: Int
    var o_v: Int
    var o_dec: Int
    var o_x: Int
    var o_h1: Int
    var o_xhat1: Int
    var o_rstd1: Int
    var o_qkv: Int
    var o_probs: Int
    var o_att: Int
    var o_h2: Int
    var o_xhat2: Int
    var o_rstd2: Int
    var o_u: Int
    var o_act: Int
    var o_hf: Int
    var o_xhatf: Int
    var o_rstdf: Int
    var o_logits: Int
    var o_tmp: Int
    var o_dx: Int
    var o_dh: Int
    var o_dqkv: Int
    var o_datt: Int
    var o_du: Int
    var o_dact: Int
    var o_dp: Int
    var o_dlogits: Int
    var o_lossbuf: Int
    var o_gscale: Int
    var o_partial: Int
    var o_splitk: Int
    var splitk_cap: Int
    var nf: Int
    # offsets into the int arena
    var i_ids: Int
    var i_tgt: Int
    var i_mask: Int
    var i_cls: Int
    var ni: Int

    def __init__(out self, cfg: Config, B: Int, use_gpu: Bool) raises:
        self.cfg = cfg.copy()
        self.B = B
        self.R = B * T
        var R = self.R
        var D = cfg.D
        var L = cfg.L
        var F = cfg.F
        var V = cfg.V
        self.nparam = Model(cfg).n
        var n = self.nparam
        var o = 0

        def take(mut o: Int, size: Int) -> Int:
            var start = o
            o += size
            return start

        self.o_w = take(o, n)
        self.o_g = take(o, n)
        self.o_m = take(o, n)
        self.o_v = take(o, n)
        self.o_dec = take(o, n)
        self.o_x = take(o, R * D)
        self.o_h1 = take(o, L * R * D)
        self.o_xhat1 = take(o, L * R * D)
        self.o_rstd1 = take(o, L * R)
        self.o_qkv = take(o, L * R * 3 * D)
        self.o_probs = take(o, L * B * cfg.H * T * T)
        self.o_att = take(o, L * R * D)
        self.o_h2 = take(o, L * R * D)
        self.o_xhat2 = take(o, L * R * D)
        self.o_rstd2 = take(o, L * R)
        self.o_u = take(o, L * R * F)
        self.o_act = take(o, L * R * F)
        self.o_hf = take(o, R * D)
        self.o_xhatf = take(o, R * D)
        self.o_rstdf = take(o, R)
        self.o_logits = take(o, R * PP * V)
        self.o_tmp = take(o, R * D)
        self.o_dx = take(o, R * D)
        self.o_dh = take(o, R * D)
        self.o_dqkv = take(o, R * 3 * D)
        self.o_datt = take(o, R * D)
        self.o_du = take(o, R * F)
        self.o_dact = take(o, R * F)
        self.o_dp = take(o, B * cfg.H * T * T)
        self.o_dlogits = take(o, R * PP * V)
        self.o_lossbuf = take(o, R * PP)
        self.o_gscale = take(o, B)
        self.o_partial = take(o, NCHUNK)
        # Scratch for split-K partials of the weight gradients (largest is W_qkv, W_1/W_2 or W_out).
        self.splitk_cap = SPLITK * max(3 * D * D, F * D, PP * V * D, 4 * F)
        self.o_splitk = take(o, self.splitk_cap)
        self.nf = o
        var oi = 0
        self.i_ids = take(oi, B * NPIX)
        self.i_tgt = take(oi, B * NPIX)
        self.i_mask = take(oi, R)
        self.i_cls = take(oi, B)
        self.ni = oi

        self.gpu = False
        self.ctx = None
        self.fdev = None
        self.idev = None
        self.fhost = List[Float32]()
        self.ihost = List[Int32]()
        comptime if has_accelerator():
            if use_gpu:
                var c = DeviceContext()
                var fb = c.enqueue_create_buffer[DType.float32](self.nf)
                var ib = c.enqueue_create_buffer[DType.int32](self.ni)
                fb.enqueue_fill(0.0)
                ib.enqueue_fill(0)
                c.synchronize()
                self.fdev = fb^
                self.idev = ib^
                self.ctx = c^
                self.gpu = True
        if not self.gpu:
            self.fhost = List[Float32](length=self.nf, fill=0.0)
            self.ihost = List[Int32](length=self.ni, fill=0)

    def device_name(self) raises -> String:
        comptime if has_accelerator():
            if self.gpu:
                return self.ctx.value().name()
        return "CPU (kernel emulation)"

    # ----------------------------------------------------------------- memory

    def F(self, off: Int) -> FP:
        if self.gpu:
            return self.fdev.value().unsafe_ptr().unsafe_mut_cast[True]().unsafe_origin_cast[
                MutAnyOrigin]().unsafe_offset(off)
        return _fp(self.fhost).unsafe_offset(off)

    def I(self, off: Int) -> IP:
        if self.gpu:
            return self.idev.value().unsafe_ptr().unsafe_mut_cast[True]().unsafe_origin_cast[
                MutAnyOrigin]().unsafe_offset(off)
        return _ip(self.ihost).unsafe_offset(off)

    def upload_f(self, off: Int, src: List[Float32]) raises:
        comptime if has_accelerator():
            if self.gpu:
                var ctx = self.ctx.value()
                var h = ctx.enqueue_create_host_buffer[DType.float32](len(src))
                ctx.synchronize()
                for i in range(len(src)):
                    h[i] = src[i]
                ctx.enqueue_copy(dst_ptr=self.F(off), src_buf=h)
                ctx.synchronize()
                return
        var p = self.F(off)
        for i in range(len(src)):
            p[unsafe_offset=i] = src[i]

    def upload_i(self, off: Int, src: List[Int32]) raises:
        comptime if has_accelerator():
            if self.gpu:
                var ctx = self.ctx.value()
                var h = ctx.enqueue_create_host_buffer[DType.int32](len(src))
                ctx.synchronize()
                for i in range(len(src)):
                    h[i] = src[i]
                ctx.enqueue_copy(dst_ptr=self.I(off), src_buf=h)
                ctx.synchronize()
                return
        var p = self.I(off)
        for i in range(len(src)):
            p[unsafe_offset=i] = src[i]

    def download_f(self, off: Int, n: Int, mut dst: List[Float32]) raises:
        comptime if has_accelerator():
            if self.gpu:
                var ctx = self.ctx.value()
                var h = ctx.enqueue_create_host_buffer[DType.float32](n)
                ctx.enqueue_copy(dst_buf=h, src_ptr=self.F(off))
                ctx.synchronize()
                for i in range(n):
                    dst[i] = h[i]
                return
        var p = self.F(off)
        for i in range(n):
            dst[i] = p[unsafe_offset=i]

    def sync(self) raises:
        comptime if has_accelerator():
            if self.gpu:
                self.ctx.value().synchronize()

    # ----------------------------------------------------------------- op launchers

    def fill(self, p: FP, n: Int, v: Float32) raises:
        comptime if has_accelerator():
            if self.gpu:
                self.ctx.value().enqueue_function[k_fill](p, v, Int32(n), grid_dim=blocks(n), block_dim=BLOCK)
                return
        for i in range(n):
            b_fill(p, v, i)

    def axpy(self, y: FP, x: FP, a: Float32, n: Int) raises:
        comptime if has_accelerator():
            if self.gpu:
                self.ctx.value().enqueue_function[k_axpy](y, x, a, Int32(n), grid_dim=blocks(n), block_dim=BLOCK)
                return
        for i in range(n):
            b_axpy(y, x, a, i)

    def gemm(self, c: FP, a: FP, b: FP, M: Int, N: Int, K: Int, Z: Int, H: Int,
             sAi: Int, sAk: Int, sBk: Int, sBj: Int, sCi: Int, sCj: Int,
             zbA: Int, zhA: Int, zbB: Int, zhB: Int, zbC: Int, zhC: Int,
             alpha: Float32, acc: Bool) raises:
        var n = M * N * Z
        var ac = 1 if acc else 0
        comptime if has_accelerator():
            if self.gpu:
                # Weight gradients have a huge K (every row of the batch) but only a few
                # output tiles: split K across blocks into scratch, then reduce.
                var tiles = Z * ((M + 63) // 64) * ((N + 63) // 64)
                var S = 1
                if Z == 1 and tiles < 128:
                    while S < SPLITK and K % (2 * S) == 0 and K // (2 * S) >= 256 and M * N * 2 * S <= self.splitk_cap:
                        S *= 2
                if S > 1:
                    var part = self.F(self.o_splitk)
                    var kc = K // S
                    self.gemm_tiled(part, a, b, M, N, kc, S, 1, sAi, sAk, sBk, sBj, N, 1,
                                    kc * sAk, 0, kc * sBk, 0, M * N, 0, 1.0, 0)
                    self.ctx.value().enqueue_function[k_splitk_reduce](
                        c, part, Int32(S), Int32(M), Int32(N), Int32(sCi), Int32(sCj), alpha, Int32(ac),
                        grid_dim=blocks(M * N), block_dim=BLOCK)
                else:
                    self.gemm_tiled(c, a, b, M, N, K, Z, H, sAi, sAk, sBk, sBj, sCi, sCj,
                                    zbA, zhA, zbB, zhB, zbC, zhC, alpha, ac)
                return
        for i in range(n):
            b_gemm(c, a, b, M, N, K, H, sAi, sAk, sBk, sBj, sCi, sCj,
                   zbA, zhA, zbB, zhB, zbC, zhC, alpha, ac, i)

    def gemm_tiled(self, c: FP, a: FP, b: FP, M: Int, N: Int, K: Int, Z: Int, H: Int,
                   sAi: Int, sAk: Int, sBk: Int, sBj: Int, sCi: Int, sCj: Int,
                   zbA: Int, zhA: Int, zbB: Int, zhB: Int, zbC: Int, zhC: Int,
                   alpha: Float32, ac: Int) raises:
        comptime if has_accelerator():
            var ctx = self.ctx.value()
            if N <= 32:  # attention outputs have N = head size: tall, narrow tiles
                var tm = (M + 127) // 128
                var tn = (N + 15) // 16
                ctx.enqueue_function[k_gemm_tiled[128, 16, 8, 1]](
                    c, a, b, Int32(M), Int32(N), Int32(K), Int32(H),
                    Int32(sAi), Int32(sAk), Int32(sBk), Int32(sBj), Int32(sCi), Int32(sCj),
                    Int32(zbA), Int32(zhA), Int32(zbB), Int32(zhB), Int32(zbC), Int32(zhC),
                    alpha, Int32(ac), Int32(tm), Int32(tn), grid_dim=Z * tm * tn, block_dim=256)
            else:
                var tm = (M + 63) // 64
                var tn = (N + 63) // 64
                ctx.enqueue_function[k_gemm_tiled[64, 64, 4, 4]](
                    c, a, b, Int32(M), Int32(N), Int32(K), Int32(H),
                    Int32(sAi), Int32(sAk), Int32(sBk), Int32(sBj), Int32(sCi), Int32(sCj),
                    Int32(zbA), Int32(zhA), Int32(zbB), Int32(zhB), Int32(zbC), Int32(zhC),
                    alpha, Int32(ac), Int32(tm), Int32(tn), grid_dim=Z * tm * tn, block_dim=256)

    def linear_fwd(self, y: FP, x: FP, w: FP, b: FP, I: Int, O: Int) raises:
        """y[R,O] = x[R,I] @ W[O,I]^T + b."""
        var R = self.R
        self.gemm(y, x, w, R, O, I, 1, 1, I, 1, 1, I, O, 1, 0, 0, 0, 0, 0, 0, 1.0, False)
        comptime if has_accelerator():
            if self.gpu:
                self.ctx.value().enqueue_function[k_add_bias](y, b, Int32(O), Int32(R * O),
                                                              grid_dim=blocks(R * O), block_dim=BLOCK)
                return
        for i in range(R * O):
            b_add_bias(y, b, O, i)

    def linear_bwd(self, dx: FP, dw: FP, db: FP, dy: FP, x: FP, w: FP, I: Int, O: Int) raises:
        """Accumulates dx += dy @ W, dW += dy^T @ x, db += sum(dy)."""
        var R = self.R
        self.gemm(dx, dy, w, R, I, O, 1, 1, O, 1, I, 1, I, 1, 0, 0, 0, 0, 0, 0, 1.0, True)
        self.gemm(dw, dy, x, O, I, R, 1, 1, 1, O, I, 1, I, 1, 0, 0, 0, 0, 0, 0, 1.0, True)
        comptime if has_accelerator():
            if self.gpu:
                self.colsum(db, db, dy, dy, O, False)
                return
        for i in range(O):
            b_bias_grad(db, dy, R, O, i)

    def colsum(self, db: FP, dg: FP, dy: FP, xhat: FP, O: Int, with_xhat: Bool) raises:
        """db += column sums of dy[R,O] (and dg += column sums of dy * xhat), split over row
        chunks so thousands of threads share the R = B*T rows instead of O threads."""
        comptime if has_accelerator():
            var ctx = self.ctx.value()
            var S = 64
            var part = self.F(self.o_splitk)
            var wx = Int32(1 if with_xhat else 0)
            ctx.enqueue_function[k_colsum_partial](part, dy, xhat, Int32(self.R), Int32(O), Int32(S), wx,
                                                   grid_dim=blocks(S * O), block_dim=BLOCK)
            ctx.enqueue_function[k_colsum_reduce](db, dg, part, Int32(O), Int32(S), wx,
                                                  grid_dim=blocks(O), block_dim=BLOCK)

    def ln_fwd(self, y: FP, xhat: FP, rstd: FP, x: FP, g: FP, b: FP) raises:
        var R = self.R
        var D = self.cfg.D
        comptime if has_accelerator():
            if self.gpu:
                self.ctx.value().enqueue_function[k_ln_fwd](y, xhat, rstd, x, g, b, Int32(D), Int32(R),
                                                            grid_dim=blocks(R), block_dim=BLOCK)
                return
        for i in range(R):
            b_ln_fwd(y, xhat, rstd, x, g, b, D, i)

    def ln_bwd(self, dx: FP, dg: FP, db: FP, dy: FP, xhat: FP, rstd: FP, g: FP) raises:
        var R = self.R
        var D = self.cfg.D
        comptime if has_accelerator():
            if self.gpu:
                var ctx = self.ctx.value()
                ctx.enqueue_function[k_ln_bwd_dx](dx, dy, xhat, rstd, g, Int32(D), Int32(R),
                                                  grid_dim=blocks(R), block_dim=BLOCK)
                self.colsum(db, dg, dy, xhat, D, True)
                return
        for i in range(R):
            b_ln_bwd_dx(dx, dy, xhat, rstd, g, D, i)
        for i in range(D):
            b_ln_bwd_dgb(dg, db, dy, xhat, R, D, i)

    def gelu_fwd(self, y: FP, x: FP, n: Int) raises:
        comptime if has_accelerator():
            if self.gpu:
                self.ctx.value().enqueue_function[k_gelu_fwd](y, x, Int32(n), grid_dim=blocks(n), block_dim=BLOCK)
                return
        for i in range(n):
            b_gelu_fwd(y, x, i)

    def gelu_bwd(self, dx: FP, dy: FP, x: FP, n: Int) raises:
        comptime if has_accelerator():
            if self.gpu:
                self.ctx.value().enqueue_function[k_gelu_bwd](dx, dy, x, Int32(n), grid_dim=blocks(n), block_dim=BLOCK)
                return
        for i in range(n):
            b_gelu_bwd(dx, dy, x, i)

    def softmax(self, p: FP, rows: Int, cols: Int) raises:
        comptime if has_accelerator():
            if self.gpu:
                self.ctx.value().enqueue_function[k_softmax_rows](p, Int32(cols), grid_dim=rows, block_dim=256)
                return
        for i in range(rows):
            b_softmax(p, cols, i)

    def softmax_bwd(self, dp: FP, p: FP, rows: Int, cols: Int, scale: Float32) raises:
        comptime if has_accelerator():
            if self.gpu:
                self.ctx.value().enqueue_function[k_softmax_bwd_rows](dp, p, Int32(cols), scale,
                                                                      grid_dim=rows, block_dim=256)
                return
        for i in range(rows):
            b_softmax_bwd(dp, p, cols, scale, i)

    def chunk_sum(self, x: FP, n: Int, square: Bool) raises -> Float32:
        var sq = 1 if square else 0
        var part = self.F(self.o_partial)
        var done = False
        comptime if has_accelerator():
            if self.gpu:
                self.ctx.value().enqueue_function[k_chunk_sum](part, x, Int32(n), Int32(sq),
                                                               grid_dim=blocks(NCHUNK), block_dim=BLOCK)
                done = True
        if not done:
            for i in range(NCHUNK):
                b_chunk_sum(part, x, n, sq, i)
        var h = List[Float32](length=NCHUNK, fill=0.0)
        self.download_f(self.o_partial, NCHUNK, h)
        var s: Float64 = 0.0
        for i in range(NCHUNK):
            s += Float64(h[i])
        return Float32(s)

    # ----------------------------------------------------------------- parameters

    def load_params(self, m: Model) raises:
        self.upload_f(self.o_w, m.w)
        var dec = List[Float32](length=m.n, fill=0.0)
        for i in range(m.n):
            dec[i] = Float32(Int(m.decay[i]))
        self.upload_f(self.o_dec, dec)
        self.fill(self.F(self.o_m), m.n, 0.0)
        self.fill(self.F(self.o_v), m.n, 0.0)
        self.sync()

    def store_params(self, mut m: Model) raises:
        self.download_f(self.o_w, m.n, m.w)

    def upload_batch(self, ids: List[Int32], tgt: List[Int32], mask: List[Int32],
                     cls: List[Int32], gscale: List[Float32]) raises:
        self.upload_i(self.i_ids, ids)
        self.upload_i(self.i_tgt, tgt)
        self.upload_i(self.i_mask, mask)
        self.upload_i(self.i_cls, cls)
        self.upload_f(self.o_gscale, gscale)

    # ----------------------------------------------------------------- forward / backward

    def forward(self, m: Model) raises:
        var D = self.cfg.D
        var F = self.cfg.F
        var V = self.cfg.V
        var H = self.cfg.H
        var L = self.cfg.L
        var R = self.R
        var hd = self.cfg.hd()
        var scale = Float32(1.0 / sqrt(Float64(hd)))
        var W = self.F(self.o_w)
        var x = self.F(self.o_x)
        var tmp = self.F(self.o_tmp)

        var n = R * D
        comptime if has_accelerator():
            if self.gpu:
                self.ctx.value().enqueue_function[k_embed](
                    x, W, self.I(self.i_ids), self.I(self.i_cls), Int32(m.o_tok), Int32(m.o_pos),
                    Int32(m.o_cls), Int32(D), Int32(V), Int32(n), grid_dim=blocks(n), block_dim=BLOCK)
        if not self.gpu:
            for i in range(n):
                b_embed(x, W, self.I(self.i_ids), self.I(self.i_cls), m.o_tok, m.o_pos, m.o_cls, D, V, i)

        for l in range(L):
            var h1 = self.F(self.o_h1 + l * R * D)
            var qkv = self.F(self.o_qkv + l * R * 3 * D)
            var probs = self.F(self.o_probs + l * self.B * H * T * T)
            var att = self.F(self.o_att + l * R * D)
            var h2 = self.F(self.o_h2 + l * R * D)
            var u = self.F(self.o_u + l * R * F)
            var act = self.F(self.o_act + l * R * F)

            self.ln_fwd(h1, self.F(self.o_xhat1 + l * R * D), self.F(self.o_rstd1 + l * R), x,
                        W.unsafe_offset(m.lo(l, m.r_ln1g)), W.unsafe_offset(m.lo(l, m.r_ln1b)))
            self.linear_fwd(qkv, h1, W.unsafe_offset(m.lo(l, m.r_wqkv)), W.unsafe_offset(m.lo(l, m.r_bqkv)), D, 3 * D)
            # S = scale * Q K^T for every (sprite, head)
            self.gemm(probs, qkv, qkv.unsafe_offset(D), T, T, hd, self.B * H, H,
                      3 * D, 1, 1, 3 * D, T, 1,
                      T * 3 * D, hd, T * 3 * D, hd, H * T * T, T * T, scale, False)
            self.softmax(probs, self.B * H * T, T)
            # O = P V, written straight into the head's columns of att
            self.gemm(att, probs, qkv.unsafe_offset(2 * D), T, hd, T, self.B * H, H,
                      T, 1, 3 * D, 1, D, 1,
                      H * T * T, T * T, T * 3 * D, hd, T * D, hd, 1.0, False)
            self.linear_fwd(tmp, att, W.unsafe_offset(m.lo(l, m.r_wo)), W.unsafe_offset(m.lo(l, m.r_bo)), D, D)
            self.axpy(x, tmp, 1.0, R * D)

            self.ln_fwd(h2, self.F(self.o_xhat2 + l * R * D), self.F(self.o_rstd2 + l * R), x,
                        W.unsafe_offset(m.lo(l, m.r_ln2g)), W.unsafe_offset(m.lo(l, m.r_ln2b)))
            self.linear_fwd(u, h2, W.unsafe_offset(m.lo(l, m.r_w1)), W.unsafe_offset(m.lo(l, m.r_b1)), D, F)
            self.gelu_fwd(act, u, R * F)
            self.linear_fwd(tmp, act, W.unsafe_offset(m.lo(l, m.r_w2)), W.unsafe_offset(m.lo(l, m.r_b2)), F, D)
            self.axpy(x, tmp, 1.0, R * D)

        self.ln_fwd(self.F(self.o_hf), self.F(self.o_xhatf), self.F(self.o_rstdf), x,
                    W.unsafe_offset(m.o_lnfg), W.unsafe_offset(m.o_lnfb))
        self.linear_fwd(self.F(self.o_logits), self.F(self.o_hf), W.unsafe_offset(m.o_wout),
                        W.unsafe_offset(m.o_bout), D, PP * V)

    def loss(self) raises -> Float32:
        """Masked cross-entropy; fills dlogits. Returns the batch-mean loss."""
        var V = self.cfg.V
        var n = self.R * PP
        var dl = self.F(self.o_dlogits)
        var lb = self.F(self.o_lossbuf)
        var lg = self.F(self.o_logits)
        var done = False
        comptime if has_accelerator():
            if self.gpu:
                self.ctx.value().enqueue_function[k_loss](
                    dl, lb, lg, self.I(self.i_tgt), self.I(self.i_mask), self.F(self.o_gscale),
                    Int32(V), Int32(n), grid_dim=blocks(n), block_dim=BLOCK)
                done = True
        if not done:
            for i in range(n):
                b_loss(dl, lb, lg, self.I(self.i_tgt), self.I(self.i_mask), self.F(self.o_gscale), V, i)
        return self.chunk_sum(lb, n, False)

    def backward(self, m: Model) raises:
        var D = self.cfg.D
        var F = self.cfg.F
        var V = self.cfg.V
        var H = self.cfg.H
        var L = self.cfg.L
        var R = self.R
        var B = self.B
        var hd = self.cfg.hd()
        var scale = Float32(1.0 / sqrt(Float64(hd)))
        var W = self.F(self.o_w)
        var G = self.F(self.o_g)
        var dx = self.F(self.o_dx)
        var dh = self.F(self.o_dh)
        var dp = self.F(self.o_dp)
        var dqkv = self.F(self.o_dqkv)
        var datt = self.F(self.o_datt)

        self.fill(dh, R * D, 0.0)
        self.linear_bwd(dh, G.unsafe_offset(m.o_wout), G.unsafe_offset(m.o_bout), self.F(self.o_dlogits),
                        self.F(self.o_hf), W.unsafe_offset(m.o_wout), D, PP * V)
        self.fill(dx, R * D, 0.0)
        self.ln_bwd(dx, G.unsafe_offset(m.o_lnfg), G.unsafe_offset(m.o_lnfb), dh, self.F(self.o_xhatf),
                    self.F(self.o_rstdf), W.unsafe_offset(m.o_lnfg))

        for l in range(L - 1, -1, -1):
            var h1 = self.F(self.o_h1 + l * R * D)
            var qkv = self.F(self.o_qkv + l * R * 3 * D)
            var probs = self.F(self.o_probs + l * B * H * T * T)
            var att = self.F(self.o_att + l * R * D)
            var h2 = self.F(self.o_h2 + l * R * D)
            var u = self.F(self.o_u + l * R * F)
            var act = self.F(self.o_act + l * R * F)

            # MLP block
            self.fill(self.F(self.o_dact), R * F, 0.0)
            self.linear_bwd(self.F(self.o_dact), G.unsafe_offset(m.lo(l, m.r_w2)), G.unsafe_offset(m.lo(l, m.r_b2)),
                            dx, act, W.unsafe_offset(m.lo(l, m.r_w2)), F, D)
            self.gelu_bwd(self.F(self.o_du), self.F(self.o_dact), u, R * F)
            self.fill(dh, R * D, 0.0)
            self.linear_bwd(dh, G.unsafe_offset(m.lo(l, m.r_w1)), G.unsafe_offset(m.lo(l, m.r_b1)),
                            self.F(self.o_du), h2, W.unsafe_offset(m.lo(l, m.r_w1)), D, F)
            self.ln_bwd(dx, G.unsafe_offset(m.lo(l, m.r_ln2g)), G.unsafe_offset(m.lo(l, m.r_ln2b)), dh,
                        self.F(self.o_xhat2 + l * R * D), self.F(self.o_rstd2 + l * R),
                        W.unsafe_offset(m.lo(l, m.r_ln2g)))

            # attention block
            self.fill(datt, R * D, 0.0)
            self.linear_bwd(datt, G.unsafe_offset(m.lo(l, m.r_wo)), G.unsafe_offset(m.lo(l, m.r_bo)),
                            dx, att, W.unsafe_offset(m.lo(l, m.r_wo)), D, D)
            # dP = dO V^T
            self.gemm(dp, datt, qkv.unsafe_offset(2 * D), T, T, hd, B * H, H,
                      D, 1, 1, 3 * D, T, 1,
                      T * D, hd, T * 3 * D, hd, H * T * T, T * T, 1.0, False)
            # dV = P^T dO
            self.gemm(dqkv.unsafe_offset(2 * D), probs, datt, T, hd, T, B * H, H,
                      1, T, D, 1, 3 * D, 1,
                      H * T * T, T * T, T * D, hd, T * 3 * D, hd, 1.0, False)
            self.softmax_bwd(dp, probs, B * H * T, T, scale)
            # dQ = dS K
            self.gemm(dqkv, dp, qkv.unsafe_offset(D), T, hd, T, B * H, H,
                      T, 1, 3 * D, 1, 3 * D, 1,
                      H * T * T, T * T, T * 3 * D, hd, T * 3 * D, hd, 1.0, False)
            # dK = dS^T Q
            self.gemm(dqkv.unsafe_offset(D), dp, qkv, T, hd, T, B * H, H,
                      1, T, 3 * D, 1, 3 * D, 1,
                      H * T * T, T * T, T * 3 * D, hd, T * 3 * D, hd, 1.0, False)
            self.fill(dh, R * D, 0.0)
            self.linear_bwd(dh, G.unsafe_offset(m.lo(l, m.r_wqkv)), G.unsafe_offset(m.lo(l, m.r_bqkv)),
                            dqkv, h1, W.unsafe_offset(m.lo(l, m.r_wqkv)), D, 3 * D)
            self.ln_bwd(dx, G.unsafe_offset(m.lo(l, m.r_ln1g)), G.unsafe_offset(m.lo(l, m.r_ln1b)), dh,
                        self.F(self.o_xhat1 + l * R * D), self.F(self.o_rstd1 + l * R),
                        W.unsafe_offset(m.lo(l, m.r_ln1g)))

        # embeddings
        var ids = self.I(self.i_ids)
        var cls = self.I(self.i_cls)
        var npos = T * D
        var ncls = (self.cfg.C + 1) * D
        var ntok = SLOTS * (V + 1) * D
        comptime if has_accelerator():
            if self.gpu:
                var ctx = self.ctx.value()
                ctx.enqueue_function[k_embed_bwd_pos](G, dx, Int32(m.o_pos), Int32(B), Int32(D), Int32(npos),
                                                      grid_dim=blocks(npos), block_dim=BLOCK)
                ctx.enqueue_function[k_embed_bwd_cls](G, dx, cls, Int32(m.o_cls), Int32(B), Int32(D), Int32(ncls),
                                                      grid_dim=blocks(ncls), block_dim=BLOCK)
                ctx.enqueue_function[k_embed_bwd_tok](G, dx, ids, Int32(m.o_tok), Int32(B), Int32(D), Int32(V),
                                                      Int32(ntok), grid_dim=blocks(ntok), block_dim=BLOCK)
        if not self.gpu:
            for i in range(npos):
                b_embed_bwd_pos(G, dx, m.o_pos, B, D, i)
            for i in range(ncls):
                b_embed_bwd_cls(G, dx, cls, m.o_cls, B, D, i)
            for i in range(ntok):
                b_embed_bwd_tok(G, dx, ids, m.o_tok, B, D, V, i)

    def optimizer_step(self, lr: Float32, step: Int, wd: Float32, clip: Float32) raises -> Float32:
        """Global-norm gradient clipping + AdamW. Returns the gradient norm before clipping."""
        var n = self.nparam
        var norm = sqrt(self.chunk_sum(self.F(self.o_g), n, True))
        var gmul: Float32 = 1.0
        if norm > clip:
            gmul = clip / norm
        var c1 = 1.0 - Float32(0.9 ** Float64(step))
        var c2 = 1.0 - Float32(0.95 ** Float64(step))
        var w = self.F(self.o_w)
        var g = self.F(self.o_g)
        var mm = self.F(self.o_m)
        var vv = self.F(self.o_v)
        var dec = self.F(self.o_dec)
        comptime if has_accelerator():
            if self.gpu:
                self.ctx.value().enqueue_function[k_adamw](w, g, mm, vv, dec, gmul, lr, c1, c2, wd, Int32(n),
                                                           grid_dim=blocks(n), block_dim=BLOCK)
                return norm
        for i in range(n):
            b_adamw(w, g, mm, vv, dec, gmul, lr, c1, c2, wd, i)
        return norm

    def zero_grad(self) raises:
        self.fill(self.F(self.o_g), self.nparam, 0.0)
