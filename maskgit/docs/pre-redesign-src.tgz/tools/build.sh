#!/bin/sh
# Builds the Mojo binaries that are older than their sources. Each binary is built to a
# temporary file and renamed into place, so a training that is already running keeps
# its executable intact.
#
#     sh tools/build.sh                # train_gpu sample gpu_check psg
#     sh tools/build.sh train_gpu      # just one
set -e
cd "$(dirname "$0")/.."
MOJO=${MOJO:-.venv/bin/mojo}
CHIP=$(sysctl -n machdep.cpu.brand_string 2>/dev/null | sed -n 's/^Apple \(M[0-9]*\).*/apple-\1/p' | tr 'M' 'm')
TARGETS=${*:-"train_gpu sample gpu_check psg"}

for t in $TARGETS; do
    if [ -f "$t" ] && [ -z "$(find "$t.mojo" src -name '*.mojo' -newer "$t" 2>/dev/null)" ]; then
        echo "$t is up to date"
        continue
    fi
    flags="-O3"
    if [ -n "$CHIP" ] && [ "$t" != "psg" ]; then
        flags="$flags --target-accelerator $CHIP"
    fi
    echo "building $t ($flags)"
    "$MOJO" build $flags "$t.mojo" -o "$t.tmp" 2>&1 | grep -v -e warning -e Crashpad -e "^ " -e "^<unknown>" -e "^Imported" -e "^Included" || true
    [ -f "$t.tmp" ] || { echo "build of $t failed" >&2; exit 1; }
    mv "$t.tmp" "$t"
done
