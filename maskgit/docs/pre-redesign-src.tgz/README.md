# pixel-sprite-gen

A small generator for **animated** 64×64 pixel-art sprite sheets, with a **hand-written training pipeline in Mojo**: no ML framework, no autograd. Every forward pass has a matching backward pass written by hand, checked against finite differences.

The model is a MaskGIT-style masked transformer that draws one frame at a time. It sees the previous frame and paints the next one. Frames are grids of palette indices (index 0 = transparent), so outputs are always crisp pixels that use only your palette.

## Setup

Tested with Mojo 1.2.0 and MAX 26.7.0 (MAX provides Mojo's GPU support) on an M2 Pro. On macOS you also need Xcode or the Xcode Command Line Tools 16+.

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
mojo --version
```

Use `apple-m1`, `apple-m3` or `apple-m4` instead of `apple-m2` below for other chips.

## psg: pipelines and progress

`psg` is a small Mojo CLI that runs stages in the background and shows their progress.

```bash
sh tools/build.sh            # builds train_gpu, sample, gpu_check and psg when sources changed

./psg run pipelines/toy.pipe                  # start a pipeline and watch it (Ctrl-C detaches)
./psg train small -- --data data_duelyst --steps 4000 --dim 64   # one training → checkpoints/small
./psg status                                  # all runs, once
./psg watch [name]                            # live: progress bar, loss, speed, ETA, loss sparkline
./psg logs <name> [stage]                     # tail of a stage's log
./psg stop <name>
./psg adopt <name> <pid> <log>                # track a train_gpu you started by hand
```

```
duelyst  ▶ running  started 2026-10-24 21:56:49
  train        ██░░░░░░░░░░░░░░░░░░░░░░  10%  step 2100/20000  loss 0.5556  12.4 pairs/s  eta 192 min  ▶ running  23m31s
               loss █▄▂▂▂▂▂▂▂▂▂▂▂▁▁▁▁▁▁▁▁
```

A pipeline is a text file of stages. Each stage is a shell command run from the project root (see `pipelines/toy.pipe` and `pipelines/duelyst.pipe`, which trains two model sizes back to back):

```
set DATA data_duelyst                 # ${DATA} is substituted below
stage prepare
  cmd .venv/bin/python tools/prepare_animations.py --atlases raw/units --out ${DATA}
  skip_if ${DATA}/meta.txt            # skip when this path exists
stage train
  cmd ./train_gpu --data ${DATA} --out checkpoints/small --steps 4000
  gpu yes                             # automatic for train_gpu, sample and gpu_check
```

How runs behave:
- Stages run in order, and a failing stage stops its pipeline.
- Runs are detached, so closing the terminal or pressing Ctrl-C in `watch` doesn't stop them.
- GPU stages from different runs wait for each other, so you can start several pipelines and they queue up.
- Everything about a run lives in `runs/<name>/`: the pipeline it ran, per-stage logs, pids, exit codes and timings.
- Progress is parsed from lines like `step 900 / 20000 | loss 0.85 | ... | eta 204 min`. Any command that prints `<word> N / M` gets a progress bar.

## Quick start (toy dataset)

```bash
# 1. Make 800 procedural looping animations (slimes squash, coins spin, potions bubble, swords bob)
python tools/make_toy_dataset.py --out sprites --per-class 200

# 2. Convert frames into the binary frame-pair format
python tools/prepare_animations.py --frames sprites --out data --looping coin,potion,slime,sword
open data/preview.png   # pairs rendered back from the binary data: check them

# 3. Check the hand-written gradients, then the GPU kernels against the CPU reference
mojo run gradcheck.mojo
mojo build -O3 --target-accelerator apple-m2 gpu_check.mojo -o gpu_check && ./gpu_check

# 4. Build and train on the GPU
mojo build -O3 --target-accelerator apple-m2 train_gpu.mojo -o train_gpu
mojo build -O3 --target-accelerator apple-m2 sample.mojo -o sample
./train_gpu --data data --out checkpoints/toy --steps 2000

# 5. Generate sprite sheets and render them
./sample --ckpt checkpoints/toy --data data --class slime --n 4 --frames 8
python tools/render.py --samples out/samples.bin --palette data/palette.txt --out out
open out/anim_000.gif
```

## Training on Duelyst

The Duelyst unit animations (idle, breathing, run, attack, hit, death) are TexturePacker atlases: a `.png` sheet plus a `.plist` with each frame's rectangle. The plist is needed to cut the frames out.

```bash
git clone --depth 1 --filter=blob:none --sparse https://github.com/tnantoka/duelyst-assets.git raw/duelyst
git -C raw/duelyst sparse-checkout set --no-cone \
  'public/duelyst-1.97.12/app/resources/units/*.png' 'public/duelyst-1.97.12/app/resources/units/*.plist'

python tools/prepare_animations.py --atlases raw/duelyst/public/duelyst-1.97.12/app/resources/units --out data_duelyst
./train_gpu --data data_duelyst --out checkpoints/duelyst --steps 20000 --dim 128 --layers 4 --lr 6e-4 --warmup 500
./sample --ckpt checkpoints/duelyst --data data_duelyst --class idle --n 4 --frames 10
python tools/render.py --samples out/samples.bin --palette data_duelyst/palette.txt --out out
```

This keeps 2,365 of the 4,122 animations: those whose motion fits in 64×64 at the art's native pixel size. That's 24,013 frame pairs and a shared 64-color palette quantized from 2,507 colors. The class is the animation type, so `--class run` asks for a run cycle.

## Using your own sprites

Put frames in one folder per animation, grouped by class. Frames play in filename order.

```
sprites/
  idle/    knight/  000.png 001.png ...     (any size; each animation is cropped together)
           slime/   000.png 001.png ...
  attack/  knight/  ...
```

Then run `python tools/prepare_animations.py --frames sprites --out data`. Every frame of an animation is cropped with the same offset (the union bounding box, bottom-center), so motion is kept. Animations bigger than 64×64 are skipped rather than resized, because resizing pixel art ruins it. Classes in `--looping` (default `breathing,idle,run`) also get a last→first pair, so generated cycles can loop.

## How it works

Each training example is a **pair of consecutive frames stacked into a 64×128 canvas**. The previous frame is on top as context, and the next frame is below as the target. The canvas is split into 2,048 tokens of 2×2 pixel patches. Each token's embedding is the sum of four sub-pixel embeddings, a position embedding and a class embedding. Because the position embedding covers both frames, it also tells the model which frame a token belongs to.

During training, a random fraction (cosine schedule) of the *target* frame's tokens is replaced by a MASK token. A bidirectional transformer predicts the 4 pixels of every masked token, with cross-entropy loss on masked tokens only. The context frame is never masked. Two kinds of dropout help at sampling time:
- **Context dropout** (`--context-drop 0.15`): the whole context frame is replaced by MASK, which teaches the model to draw a first frame from nothing.
- **Class dropout** (`--cfg-drop 0.1`): the class is dropped, which enables classifier-free guidance.

Sampling a sheet:
1. Start with an empty (all-MASK) context and draw frame 0. On each of ~12 steps the model proposes pixels for every masked token, keeps the most confident ones and re-masks the rest.
2. Move frame 0 into the context slot and draw frame 1.
3. Repeat for as many frames as you ask for.

| File | What it does |
|---|---|
| `src/kernels.mojo` | SIMD matmuls (3 layouts), layer norm, GELU, softmax: forward and backward |
| `src/model.mojo` | Canvas geometry, flat parameter buffer, forward, hand-written backward, AdamW, checkpoints |
| `src/data.mojo` | Frame-pair loader, target-frame masking and context dropout, CLI helpers |
| `src/engine.mojo` | Batched GPU engine: tiled shared-memory matmul, split-K weight gradients, block-per-row softmax |
| `train_gpu.mojo` | GPU training loop: warmup + cosine LR, gradient clipping, logging, checkpoints |
| `train.mojo` | Same training loop on one CPU core (slow at this canvas size) |
| `sample.mojo` | Frame-by-frame sheet generation with temperature and classifier-free guidance (GPU, or `--cpu`) |
| `gradcheck.mojo` | Finite-difference check of every parameter tensor |
| `gpu_check.mojo` | Compares GPU logits, loss, gradients and an AdamW step against the CPU model |
| `tools/prepare_animations.py` | Atlases or frame folders → palette-indexed frame pairs, plus a preview |
| `tools/render.py` | Samples → `sheet_NNN.png` (frames side by side), `anim_NNN.gif`, `grid.png` |
| `tools/make_toy_dataset.py` | Procedural looping toy animations |
| `psg.mojo`, `src/pipeline.mojo` | The pipeline CLI: detached workers, GPU queueing, progress parsing, live view |
| `tools/build.sh`, `pipelines/*.pipe` | Incremental builds (safe while training runs) and example pipelines |

## Useful flags

`train_gpu`: `--dim 64 --layers 4 --heads 4 --mlp 256 --batch 8 --lr 1e-3 --warmup 100 --steps 2000 --cfg-drop 0.1 --context-drop 0.15 --flip 0.0 --resume checkpoints/x`

`--flip` mirrors pairs with that probability. Duelyst units all face right, so it's off by default.

`sample`: `--class <name|id|none> --n 4 --frames 8 --batch 4 --steps 12 --temperature 0.7 --guidance 2.0 --seed 0 --cpu --init <pair>`

`--init` takes frame 0 from a dataset pair instead of drawing it, and the model animates that frame. Drawing frame 0 from nothing tends to collapse to an empty frame, so this gives much better sheets.

## Speed and memory (M2 Pro)

Attention over 2,048 tokens dominates, and the attention matrices for the backward pass are stored for the whole batch. Batch 8 uses about 3–3.5 GB of GPU buffers.

| Model | Parameters | Training |
|---|---|---|
| `--dim 64 --layers 4` | 0.36M | ~22 frame pairs/s |
| `--dim 128 --layers 4` | 1.1M | ~12 frame pairs/s |
| `--dim 128 --layers 6` | 1.5M | ~8 frame pairs/s |

Sampling on the GPU takes about 0.5 s per frame per sheet, and several sheets run in parallel with `--batch`. With `--cpu` it takes about 20 s per frame.

## Limitations and next steps

- **Drift:** frames are chained, so small errors add up over long sheets, and a cycle won't close perfectly on its last frame. Conditioning on frame 0 as well as the previous frame (a 3-frame canvas) would anchor the unit's identity.
- **Big animations are skipped:** about 40% of Duelyst animations (mostly attacks with lunges) don't fit in 64×64. An 80×80 or 96×96 frame would keep them, at a steep attention cost.
- **Speed:** a fused attention kernel (flash-attention style) would avoid storing the 2048×2048 attention matrices and is the next big speed and memory win.
- **Animate your own sprite:** `sample --init` already starts from a dataset frame. Loading a user PNG (quantized to the palette) is the missing step.
- Checkpoints from the old 32×32 still-sprite model don't load in this version. The pre-animation source is in `docs/pixel-sprite-gen.zip`.
