# Train on the GPU (Apple M-series via Metal, or NVIDIA/AMD) with the batched engine.
#
#     mojo build -O3 train_gpu.mojo -o train_gpu
#     ./train_gpu --data data --out checkpoints/sprites --steps 2000 --batch 8
#
# Checkpoints are the same format as train.mojo, so sample.mojo works unchanged.
# Pass --cpu to run the identical kernels as CPU loops (slow; for debugging only).

from std.sys import argv
from std.math import cos
from std.os import makedirs
from std.os.path import dirname
from std.random import seed, random_float64, random_ui64
from std.time import perf_counter_ns
from src.model import Config, Model, T, PP, NPIX
from src.data import Dataset, random_mask, apply_mask, arg_str, arg_int, arg_float
from src.engine import Engine


def main() raises:
    var a = argv()
    var args = List[String]()
    var use_gpu = True
    for i in range(len(a)):
        args.append(String(a[i]))
        if String(a[i]) == "--cpu":
            use_gpu = False

    var data_dir = arg_str(args, "--data", "data")
    var out = arg_str(args, "--out", "checkpoints/sprites")
    var steps = arg_int(args, "--steps", 2000)
    var batch = arg_int(args, "--batch", 8)
    var lr_max = Float32(arg_float(args, "--lr", 1e-3))
    var wd = Float32(arg_float(args, "--weight-decay", 0.05))
    var warmup = arg_int(args, "--warmup", 100)
    var cfg_drop = arg_float(args, "--cfg-drop", 0.1)
    var context_drop = arg_float(args, "--context-drop", 0.15)  # chance to train first-frame generation
    var flip_prob = arg_float(args, "--flip", 0.0)  # chance to mirror a pair (flips which way units face)
    var log_every = arg_int(args, "--log-every", 10)
    var save_every = arg_int(args, "--save-every", 250)
    var resume = arg_str(args, "--resume", "")
    seed(arg_int(args, "--seed", 0))

    var ds = Dataset(data_dir)
    print("dataset:", ds.N, "frame pairs,", ds.V, "colors,", ds.C, "classes")
    var dim = arg_int(args, "--dim", 64)
    var cfg = Config(
        V=ds.V, C=ds.C, D=dim,
        L=arg_int(args, "--layers", 4),
        H=arg_int(args, "--heads", 4),
        F=arg_int(args, "--mlp", 4 * dim),
    )
    if cfg.D % cfg.H != 0:
        raise Error("--dim must be divisible by --heads")
    var m = Model(cfg)
    m.init_weights()
    if resume.byte_length() > 0:
        m.load_weights(resume)
        print("resumed weights from", resume)
    print("model:", m.n, "parameters (D", cfg.D, "L", cfg.L, "H", cfg.H, "F", cfg.F, ") | batch", batch)

    var e = Engine(cfg, batch, use_gpu)
    print("device:", e.device_name(), "|", Float32(Float64(e.nf) * 4.0 / 1e9), "GB of buffers")
    if use_gpu and not e.gpu:
        print("warning: no GPU found by Mojo, falling back to slow CPU kernel emulation")
    e.load_params(m)
    var d = dirname(out)
    if d.byte_length() > 0:
        makedirs(d, exist_ok=True)

    var ids = List[Int32](length=batch * NPIX, fill=0)
    var tgt = List[Int32](length=batch * NPIX, fill=0)
    var mask_i = List[Int32](length=batch * T, fill=0)
    var cls = List[Int32](length=batch, fill=0)
    var gscale = List[Float32](length=batch, fill=0.0)
    var target = List[Int](length=NPIX, fill=0)
    var masked_ids = List[Int](length=NPIX, fill=0)
    var mask = List[Bool](length=T, fill=False)
    var order = List[Int](length=T, fill=0)

    var t0 = perf_counter_ns()
    var loss_acc: Float64 = 0.0
    var norm_acc: Float64 = 0.0
    for step in range(1, steps + 1):
        var lr: Float32
        if step <= warmup:
            lr = lr_max * Float32(step) / Float32(warmup)
        else:
            var prog = Float64(step - warmup) / Float64(max(1, steps - warmup))
            lr = lr_max * Float32(0.1 + 0.9 * 0.5 * (1.0 + cos(3.141592653589793 * prog)))

        # Build the batch on the CPU (cheap), then upload it in one go.
        for b in range(batch):
            var i = Int(random_ui64(0, UInt64(ds.N - 1)))
            ds.pair(i, random_float64() < flip_prob, target)
            var c = Int(ds.labels[i])
            if random_float64() < cfg_drop:
                c = cfg.C
            var n_masked = random_mask(mask, order)
            apply_mask(masked_ids, target, mask, cfg.V, random_float64() < context_drop)
            for p in range(NPIX):
                tgt[b * NPIX + p] = Int32(target[p])
                ids[b * NPIX + p] = Int32(masked_ids[p])
            for t in range(T):
                mask_i[b * T + t] = 1 if mask[t] else 0
            cls[b] = Int32(c)
            gscale[b] = Float32(1.0 / Float64(n_masked * PP * batch))
        e.upload_batch(ids, tgt, mask_i, cls, gscale)

        e.zero_grad()
        e.forward(m)
        var loss = e.loss()
        e.backward(m)
        var norm = e.optimizer_step(lr, step, wd, 1.0)
        loss_acc += Float64(loss)
        norm_acc += Float64(norm)

        if step % log_every == 0 or step == steps:
            e.sync()
            var n = Float64(log_every if step % log_every == 0 else step % log_every)
            var secs = Float64(perf_counter_ns() - t0) / 1e9
            var sps = Float64(step * batch) / secs
            var eta = Float64((steps - step) * batch) / sps
            print("step", step, "/", steps, "| loss", Float32(loss_acc / n), "| grad norm",
                  Float32(norm_acc / n), "| lr", lr, "|", Float32(sps), "pairs/s | eta",
                  Int(eta / 60.0), "min", flush=True)
            loss_acc = 0.0
            norm_acc = 0.0
        if step % save_every == 0 or step == steps:
            e.store_params(m)
            m.save(out)
            print("saved", out + ".bin", flush=True)
