# Generate sprites with iterative unmasking (MaskGIT) and classifier-free guidance.
#
#     mojo run sample.mojo --ckpt checkpoints/sprites --data data --class slime --n 16
#     python tools/render.py --samples out/samples.bin --palette data/palette.txt --out out

from std.sys import argv
from std.math import cos, exp, log
from std.os import makedirs
from std.os.path import dirname
from std.random import seed, random_float64
from src.kernels import ptr, copy
from src.model import Config, Model, Work, forward, T, PP, NPIX, pix_index
from src.data import arg_str, arg_int, arg_float


def class_id(name: String, data_dir: String, C: Int) raises -> Int:
    """Accepts a class name from <data>/classes.txt, a number, or 'none'."""
    if name == "none":
        return C
    var f = open(data_dir + "/classes.txt", "r")
    var txt = f.read()
    f.close()
    var i = 0
    for line in txt.splitlines():
        if line == name:
            return i
        i += 1
    return Int(name)


def main() raises:
    var a = argv()
    var args = List[String]()
    for i in range(len(a)):
        args.append(String(a[i]))

    var ckpt = arg_str(args, "--ckpt", "checkpoints/sprites")
    var data_dir = arg_str(args, "--data", "data")
    var n_samples = arg_int(args, "--n", 16)
    var n_steps = arg_int(args, "--steps", 12)
    var temp = Float32(arg_float(args, "--temperature", 0.7))
    var guidance = Float32(arg_float(args, "--guidance", 2.0))
    var choice_noise = arg_float(args, "--choice-noise", 2.0)
    var out = arg_str(args, "--out", "out/samples.bin")
    seed(arg_int(args, "--seed", 0))

    var cfg = Config.load(ckpt + ".cfg")
    var m = Model(cfg)
    m.load_weights(ckpt)
    var wk = Work(cfg)
    var V = cfg.V
    var cls = class_id(arg_str(args, "--class", "0"), data_dir, cfg.C)
    print("sampling", n_samples, "sprites, class", cls, "| guidance", guidance, "| steps", n_steps)

    var lc = List[Float32](length=T * PP * V, fill=0.0)  # conditional logits
    var ids = List[Int](length=NPIX, fill=V)
    var proposal = List[Int](length=NPIX, fill=0)
    var masked = List[Bool](length=T, fill=True)
    var conf = List[Float64](length=T, fill=0.0)
    var probs = List[Float32](length=V, fill=0.0)
    var result = List[UInt8]()

    for _ in range(n_samples):
        for i in range(NPIX):
            ids[i] = V
        for t in range(T):
            masked[t] = True
        var n_masked = T

        for s in range(n_steps):
            forward(m, wk, ids, cls)
            copy(ptr(lc), ptr(wk.logits), T * PP * V)
            var use_cfg = guidance != 1.0 and cls != cfg.C
            if use_cfg:
                forward(m, wk, ids, cfg.C)  # unconditional pass; wk.logits now holds it
            var progress = Float64(s + 1) / Float64(n_steps)

            # Propose pixels for every masked token and score the token's confidence.
            for t in range(T):
                if not masked[t]:
                    continue
                var c: Float64 = 0.0
                for k in range(PP):
                    var o = (t * PP + k) * V
                    var mx: Float32 = -1e30
                    for j in range(V):
                        var l = lc[o + j]
                        if use_cfg:
                            var lu = wk.logits[o + j]
                            l = lu + guidance * (l - lu)
                        l /= temp
                        probs[j] = l
                        mx = max(mx, l)
                    var z: Float32 = 0.0
                    for j in range(V):
                        probs[j] = exp(probs[j] - mx)
                        z += probs[j]
                    var r = Float32(random_float64()) * z
                    var pick = V - 1
                    for j in range(V):
                        r -= probs[j]
                        if r <= 0.0:
                            pick = j
                            break
                    proposal[pix_index(t, k)] = pick
                    c += log(Float64(probs[pick] / z) + 1e-12)
                # Gumbel noise on confidence, annealed to zero: explores early, commits late.
                var u = max(random_float64(), 1e-12)
                conf[t] = c + choice_noise * (1.0 - progress) * (-log(-log(u) + 1e-12))

            # How many tokens stay masked after this step (cosine schedule).
            var keep = Int(cos(1.5707963267948966 * progress) * Float64(T))
            if s == n_steps - 1:
                keep = 0
            keep = min(keep, n_masked - 1)
            keep = max(keep, 0)

            # Commit every masked token except the `keep` least confident ones.
            var still = List[Bool](length=T, fill=False)
            for _ in range(keep):
                var best = -1
                for t in range(T):
                    if masked[t] and not still[t] and (best < 0 or conf[t] < conf[best]):
                        best = t
                still[best] = True
            for t in range(T):
                if masked[t] and not still[t]:
                    for k in range(PP):
                        var p = pix_index(t, k)
                        ids[p] = proposal[p]
                    masked[t] = False
            n_masked = keep

        for i in range(NPIX):
            result.append(UInt8(ids[i]))

    var d = dirname(out)
    if d.byte_length() > 0:
        makedirs(d, exist_ok=True)
    var f = open(out, "w")
    f.write_bytes(Span(result))
    f.close()
    print("wrote", out)
