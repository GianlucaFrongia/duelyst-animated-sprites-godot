# pixel-sprite-gen

A small 32×32 pixel-art sprite generator with a **hand-written training pipeline in Mojo**: no ML framework, no autograd. Every forward pass has a matching backward pass written by hand, checked against finite differences.

The model is a MaskGIT-style masked transformer. Each sprite is a grid of palette indices (index 0 = transparent), so outputs are always crisp pixels that use only your palette.

## Setup

Tested with Mojo 1.2.0 and MAX 26.7.0 (MAX provides Mojo's GPU support). On macOS you also need Xcode or the Xcode Command Line Tools 16+.

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
mojo --version
```

## Quick start (toy dataset)

```bash
# 1. Make 2,000 procedural sprites (slime / potion / sword / coin) to test the pipeline
python tools/make_toy_dataset.py --out sprites --per-class 500

# 2. Convert PNGs into the binary, palette-indexed format
python tools/prepare_data.py --input sprites --out data

# 3. Check the hand-written gradients (do this after every change to the model)
mojo run gradcheck.mojo

# 4. Build optimized binaries and train
mojo build -O3 train.mojo -o train
mojo build -O3 sample.mojo -o sample
./train --data data --out checkpoints/sprites --steps 2000

# 5. Generate and render
./sample --ckpt checkpoints/sprites --data data --class slime --n 16
python tools/render.py --samples out/samples.bin --palette data/palette.txt --out out
open out/grid.png
```

## Training on the Apple GPU (M1/M2/M3/M4)

`train_gpu.mojo` runs the whole batch on the GPU: every forward and backward op is a GPU kernel (`src/engine.mojo`), activations stay in GPU memory, and only the batch inputs and two numbers per step cross over. Checkpoints use the same format, so `sample` works unchanged.

```bash
# 1. Verify the GPU kernels against the CPU reference (must print "engine matches")
mojo build -O3 --target-accelerator apple-m2 gpu_check.mojo -o gpu_check && ./gpu_check

# 2. Train on the GPU
mojo build -O3 --target-accelerator apple-m2 train_gpu.mojo -o train_gpu
./train_gpu --data data --out checkpoints/sprites --steps 2000 --batch 32
```

Use `apple-m1`, `apple-m3` or `apple-m4` for other chips. The first lines of output show which device is used. If it says "CPU (kernel emulation)", Mojo didn't find the GPU: see Modular's GPU troubleshooting guide (max.modular.com/gpu/hardware-compatibility).

How the GPU code is organized: each op is written once as a per-thread body function (`b_*`). On the GPU it is launched as a kernel (`k_*`, one thread per output value); without a GPU the same body runs as a CPU loop. That's what `./gpu_check --cpu` exercises, and it's how the kernel logic was tested without a Mac.

The kernels are deliberately simple (one thread per output, no shared-memory tiling), so they won't reach the GPU's peak. Tiling the `gemm` kernel is the next performance step.

## Using your own sprites

Put PNGs in one folder per class. The folder name becomes the class you sample with.

```
sprites/
  king/     king_01.png  king_02.png ...
  knight/   ...
  potion/   ...
```

Sprites must be 32×32 or a clean integer upscale (64×64, 128×128…). If your art uses more colors than `--max-colors` (default 32), it is quantized to a shared palette.

## How it works

The 32×32 image is split into 256 tokens, each a 2×2 patch of palette indices. Patching keeps attention 16× cheaper than one token per pixel. Each token's embedding is the sum of four sub-pixel embeddings, a position embedding, and a class embedding.

During training, a random fraction of tokens (cosine schedule) is replaced by a MASK token. A bidirectional transformer predicts the 4 pixels of every masked token, with cross-entropy loss on masked tokens only. 10% of the time the class is dropped, which enables classifier-free guidance at sampling time.

Sampling starts fully masked. On each of ~12 steps the model proposes pixels for every masked token, keeps the most confident tokens, and re-masks the rest.

| File | What it does |
|---|---|
| `src/kernels.mojo` | SIMD matmuls (3 layouts), layer norm, GELU, softmax — forward and backward |
| `src/model.mojo` | Flat parameter buffer, forward, hand-written backward, AdamW, checkpoints |
| `src/data.mojo` | Dataset loader, masking schedule, CLI helpers |
| `train.mojo` | Training loop: warmup + cosine LR, gradient clipping, logging, checkpoints |
| `sample.mojo` | Iterative unmasking with temperature and classifier-free guidance |
| `gradcheck.mojo` | Finite-difference check of every parameter tensor |
| `src/engine.mojo` | Batched GPU engine: 19 kernels for the full forward/backward/AdamW |
| `train_gpu.mojo` | GPU training loop (same flags as `train`, default batch 32) |
| `gpu_check.mojo` | Compares GPU logits, loss, gradients and an AdamW step against the CPU model |
| `tools/*.py` | Toy data, PNG → binary conversion, binary → PNG rendering |

## Useful flags

`train`: `--dim 64 --layers 4 --heads 4 --mlp 256 --batch 16 --lr 1e-3 --steps 2000 --cfg-drop 0.1 --resume checkpoints/sprites`

`sample`: `--class <name|id|none> --n 16 --steps 12 --temperature 0.7 --guidance 2.0 --seed 0`

## Speed

The default model (~225k parameters) runs on **one CPU core with SIMD**, at roughly 20 sprites/s on a single cloud CPU core. An M-series performance core should be in the same range or faster. 2,000 steps × batch 16 is about 25–30 minutes at that rate.

## Next steps

- **Faster GPU matmuls:** tile `b_gemm` with threadgroup shared memory.
- **GPU sampling:** `sample.mojo` still runs on the CPU; it's fast enough for small batches.
- **Text prompts:** replace the class embedding with a projected text embedding (e.g. from a frozen CLIP model, computed in Python) and keep the rest unchanged.
- **Bigger model:** `--dim 128 --layers 6` once you have 10k+ real sprites.

## What to expect

`docs/early_samples.png` shows samples after only ~550 steps (about 7 minutes) on the toy dataset. Class shapes are already clear, while colors inside a sprite are still noisy. Longer training and a lower `--temperature` make colors more coherent.
