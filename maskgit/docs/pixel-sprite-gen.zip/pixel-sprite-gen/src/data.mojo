# Loads the binary dataset written by tools/prepare_data.py, plus a tiny CLI arg helper.

from std.math import cos
from std.random import random_float64, random_ui64
from src.model import T, PP, NPIX, IMG, pix_index


struct Dataset(Movable):
    var pixels: List[UInt8]  # N * 1024
    var labels: List[UInt8]  # N
    var classes: List[String]
    var N: Int
    var V: Int
    var C: Int

    def __init__(out self, dir: String) raises:
        self.N = 0
        self.V = 0
        self.C = 0
        var f = open(dir + "/meta.txt", "r")
        var txt = f.read()
        f.close()
        for line in txt.splitlines():
            var kv = line.split(" ")
            if len(kv) < 2:
                continue
            if kv[0] == "N":
                self.N = Int(kv[1])
            elif kv[0] == "V":
                self.V = Int(kv[1])
            elif kv[0] == "C":
                self.C = Int(kv[1])
        var pf = open(dir + "/pixels.bin", "r")
        self.pixels = pf.read_bytes()
        pf.close()
        var lf = open(dir + "/labels.bin", "r")
        self.labels = lf.read_bytes()
        lf.close()
        if len(self.pixels) != self.N * NPIX or len(self.labels) != self.N:
            raise Error("dataset files do not match meta.txt")
        self.classes = List[String]()
        var cf = open(dir + "/classes.txt", "r")
        var ctxt = cf.read()
        cf.close()
        for line in ctxt.splitlines():
            if line.byte_length() > 0:
                self.classes.append(String(line))

    def sprite(self, i: Int, flip: Bool, mut out: List[Int]):
        """Copies sprite i into out (1024 palette indices), optionally mirrored horizontally."""
        var base = i * NPIX
        for y in range(IMG):
            for x in range(IMG):
                var sx = IMG - 1 - x if flip else x
                out[y * IMG + x] = Int(self.pixels[base + y * IMG + sx])


def random_mask(mut mask: List[Bool], mut order: List[Int]) -> Int:
    """MaskGIT cosine schedule: mask a random fraction cos(pi/2 * u) of tokens. Returns count."""
    var u = random_float64()
    var ratio = cos(1.5707963267948966 * u)
    var n = Int(ratio * Float64(T) + 0.999)
    n = max(1, min(T, n))
    for t in range(T):
        order[t] = t
        mask[t] = False
    for i in range(n):  # partial Fisher-Yates shuffle
        var j = i + Int(random_ui64(0, UInt64(T - 1 - i)))
        var tmp = order[i]
        order[i] = order[j]
        order[j] = tmp
        mask[order[i]] = True
    return n


def apply_mask(mut ids: List[Int], target: List[Int], mask: List[Bool], mask_id: Int):
    for i in range(NPIX):
        ids[i] = target[i]
    for t in range(T):
        if mask[t]:
            for k in range(PP):
                ids[pix_index(t, k)] = mask_id


# ------------------------------------------------------------------ CLI args


def arg_str(args: List[String], name: String, default: String) -> String:
    for i in range(len(args) - 1):
        if args[i] == name:
            return args[i + 1]
    return default


def arg_int(args: List[String], name: String, default: Int) raises -> Int:
    var s = arg_str(args, name, "")
    return Int(s) if s.byte_length() > 0 else default


def arg_float(args: List[String], name: String, default: Float64) raises -> Float64:
    var s = arg_str(args, name, "")
    return Float64(s) if s.byte_length() > 0 else default
