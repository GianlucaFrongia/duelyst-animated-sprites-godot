"""Turn a folder of 32x32 sprites into the palette-indexed binary format the Mojo trainer reads.

Input layout (folder name = class label):
    sprites/
      character/  king.png  knight.png ...
      item/       potion.png ...

Output (in --out):
    pixels.bin   N * 1024 bytes, one palette index per pixel, row-major
    labels.bin   N bytes, class id per sprite
    palette.txt  one "r g b" line per palette index (index 0 is transparent)
    classes.txt  one class name per line, in class-id order
    meta.txt     N / V (palette size incl. transparent) / C (number of classes)

    python tools/prepare_data.py --input sprites --out data --max-colors 32
"""
import argparse
from collections import Counter
from pathlib import Path

import numpy as np
from PIL import Image

SIZE = 32


def load_sprite(path):
    img = Image.open(path).convert("RGBA")
    w, h = img.size
    if (w, h) != (SIZE, SIZE):
        # Accept clean integer upscales (e.g. 64x64, 128x128) and shrink them back.
        if w == h and w % SIZE == 0:
            img = img.resize((SIZE, SIZE), Image.NEAREST)
        else:
            return None
    return np.asarray(img, dtype=np.uint8)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="sprites")
    ap.add_argument("--out", default="data")
    ap.add_argument("--max-colors", type=int, default=32,
                    help="palette size including the transparent index")
    ap.add_argument("--alpha-threshold", type=int, default=128)
    args = ap.parse_args()

    root = Path(args.input)
    classes = sorted(p.name for p in root.iterdir() if p.is_dir())
    if not classes:
        raise SystemExit(f"no class folders found in {root}")
    if len(classes) > 255:
        raise SystemExit("at most 255 classes are supported")

    sprites, labels, skipped = [], [], 0
    for cid, name in enumerate(classes):
        for path in sorted((root / name).glob("*.png")):
            arr = load_sprite(path)
            if arr is None:
                skipped += 1
                continue
            sprites.append(arr)
            labels.append(cid)
    if not sprites:
        raise SystemExit("no usable 32x32 sprites found")
    stack = np.stack(sprites)  # N, 32, 32, 4
    opaque = stack[..., 3] >= args.alpha_threshold
    rgb = stack[..., :3]

    # Build the palette: exact colors if they fit, otherwise median-cut quantization.
    n_slots = args.max_colors - 1
    counts = Counter(map(tuple, rgb[opaque].reshape(-1, 3)))
    if len(counts) <= n_slots:
        palette = np.array([c for c, _ in counts.most_common()], dtype=np.int32)
    else:
        pixels = rgb[opaque].reshape(1, -1, 3)
        q = Image.fromarray(pixels.astype(np.uint8), "RGB").quantize(
            colors=n_slots, method=Image.Quantize.MEDIANCUT)
        palette = np.array(q.getpalette()[: n_slots * 3], dtype=np.int32).reshape(-1, 3)
        print(f"{len(counts)} unique colors -> quantized to {n_slots}")

    # Map every opaque pixel to its nearest palette color (index + 1; 0 = transparent).
    flat = rgb.reshape(-1, 3).astype(np.int32)
    idx = np.zeros(len(flat), dtype=np.uint8)
    op = opaque.reshape(-1)
    chunk = 1 << 18
    for s in range(0, len(flat), chunk):
        part = flat[s:s + chunk]
        d = ((part[:, None, :] - palette[None, :, :]) ** 2).sum(-1)
        idx[s:s + chunk] = d.argmin(1).astype(np.uint8) + 1
    idx[~op] = 0

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    idx.tofile(out / "pixels.bin")
    np.array(labels, dtype=np.uint8).tofile(out / "labels.bin")
    V = len(palette) + 1
    with open(out / "palette.txt", "w") as f:
        f.write("0 0 0\n")  # index 0: transparent (color unused)
        for r, g, b in palette:
            f.write(f"{r} {g} {b}\n")
    (out / "classes.txt").write_text("\n".join(classes) + "\n")
    (out / "meta.txt").write_text(f"N {len(sprites)}\nV {V}\nC {len(classes)}\n")
    print(f"{len(sprites)} sprites, {V} palette entries, {len(classes)} classes "
          f"({skipped} skipped) -> {out}/")


if __name__ == "__main__":
    main()
