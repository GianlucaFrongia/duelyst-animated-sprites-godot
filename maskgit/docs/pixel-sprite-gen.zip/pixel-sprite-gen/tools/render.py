"""Render samples.bin (written by sample.mojo) into PNGs.

    python tools/render.py --samples out/samples.bin --palette data/palette.txt --out out/

Writes each sprite as a true 32x32 PNG with transparency, plus an upscaled preview grid.
"""
import argparse
import math
from pathlib import Path

import numpy as np
from PIL import Image


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--samples", default="out/samples.bin")
    ap.add_argument("--palette", default="data/palette.txt")
    ap.add_argument("--out", default="out")
    ap.add_argument("--scale", type=int, default=8)
    args = ap.parse_args()

    pal = np.loadtxt(args.palette, dtype=np.uint8).reshape(-1, 3)
    idx = np.fromfile(args.samples, dtype=np.uint8).reshape(-1, 32, 32)
    rgba = np.zeros(idx.shape + (4,), dtype=np.uint8)
    rgba[..., :3] = pal[np.minimum(idx, len(pal) - 1)]
    rgba[..., 3] = np.where(idx == 0, 0, 255)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    n = len(rgba)
    cols = math.ceil(math.sqrt(n))
    rows = math.ceil(n / cols)
    grid = Image.new("RGBA", (cols * 34, rows * 34), (40, 40, 48, 255))
    for i, a in enumerate(rgba):
        img = Image.fromarray(a, "RGBA")
        img.save(out / f"sprite_{i:03d}.png")
        grid.alpha_composite(img, ((i % cols) * 34 + 1, (i // cols) * 34 + 1))
    s = args.scale
    grid.resize((grid.width * s, grid.height * s), Image.NEAREST).save(out / "grid.png")
    print(f"rendered {n} sprites -> {out}/grid.png")


if __name__ == "__main__":
    main()
